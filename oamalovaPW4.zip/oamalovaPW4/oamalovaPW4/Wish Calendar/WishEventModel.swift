//
//  WishEventModel.swift
//  oamalovaPW4
//

import UIKit

struct WishEventModel {
    var title: String
    var description: String
    var startDate: String
    var endDate: String
}

