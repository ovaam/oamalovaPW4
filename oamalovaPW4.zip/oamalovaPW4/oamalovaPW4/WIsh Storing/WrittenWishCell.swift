//
//  WrittenWishCell.swift
//  oamalovaPW4
//
//  Created by Малова Олеся on 03.12.2024.
//

import UIKit

final class WrittenWishCell: UITableViewCell {
    static let reuseId: String = "WrittenWishCell"
    
    private let wishLabel: UILabel = UILabel()
    private let wrap: UIView = UIView()
    private let deleteButton: UIButton = UIButton()
    //private let updateButton: UIButton = UIButton()
    
    var deletePressed: ((String)->())?
    var updatePressed: ((String)->())?
    
    
    // MARK: - Lifecycle
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        configureUI()
        setDeleteButton()
        //setUpdateButton()
    }
    
    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func configure(with wish: String) {
        wishLabel.text = wish
    }
    
    private func configureUI() {
        selectionStyle = .none
        backgroundColor = .clear
        
        addSubview(wrap)
        wrap.backgroundColor = Constants.wrapColor
        wrap.layer.cornerRadius = Constants.wrapRadius
        
        wrap.pinVertical(to: self, Constants.wrapOffsetV)
        wrap.pinHorizontal(to: self, Constants.wrapOffsetH)
        
        wrap.addSubview(wishLabel)
        wishLabel.pin(to: wrap, Constants.wishLabelOffset)
    }
    private func setDeleteButton() {
        contentView.addSubview(deleteButton)
        
        deleteButton.setImage(UIImage(systemName: "trash.fill"), for: .normal)
        deleteButton.pinRight(to: contentView.trailingAnchor, Constants.deleteButtonRight)
        deleteButton.pinVertical(to: contentView, Constants.deleteButtonVertical )
        
        deleteButton.addTarget(self, action: #selector(deleteWish), for: .touchUpInside)
    }
    
    @objc func deleteWish() {
        if let text = wishLabel.text {
            deletePressed?(text)
        }
    }
    
//    private func setUpdateButton() {
//        contentView.addSubview(updateButton)
//
//        updateButton.setImage(UIImage(systemName: "pencil"), for: .normal)
//        updateButton.pinRight(to: contentView.trailingAnchor, Constants.updateButtonRight)
//        updateButton.pinVertical(to: contentView, Constants.updateButtonVertical)
//
//        updateButton.addTarget(self, action: #selector(updateWish), for: .touchUpInside)
//    }
    
//    @objc func updateWish() {
//        if let text = wishLabel.text {
//            updatePressed?(text)
//        }
//    }
}

